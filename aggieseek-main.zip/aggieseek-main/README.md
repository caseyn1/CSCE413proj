# AggieSeek
<img src="https://i.imgur.com/uTlHU6S.png"></img>

AggieSeek is a web application that automatically tracks and notifies students upon course openings at Texas A&M University. Create a new account and be the first to enroll in your courses today!

**Visit our website at www.aggieseek.net!**

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/I2I515VJDX)
