export default function About() {
  return <div className="p-8">Hello!</div>;
}
