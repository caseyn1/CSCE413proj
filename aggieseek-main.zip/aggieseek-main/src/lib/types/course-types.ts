export interface Term {
  code: string;
  desc: string;
  startDate: string;
}

export interface Course {
  course: string;
  title: string;
}
